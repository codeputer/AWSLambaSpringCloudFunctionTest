package com.morethanheroic.uppercase.handler.aws;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;
import com.amazonaws.services.lambda.runtime.Context;


import com.morethanheroic.uppercase.domain.UppercaseRequest;
import com.morethanheroic.uppercase.domain.UppercaseResponse;

public class UppercaseFunctionHandler extends SpringBootRequestHandler<UppercaseRequest, UppercaseResponse>
{
  @Override
  public Object handleRequest(UppercaseRequest event, Context context)
  {
    System.out.println("UppercaseFunctionHandler - entered the handleRequest method");
    return super.handleRequest(event, context);
  }
}
