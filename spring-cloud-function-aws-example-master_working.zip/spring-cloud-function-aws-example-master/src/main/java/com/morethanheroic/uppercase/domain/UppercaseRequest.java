package com.morethanheroic.uppercase.domain;

public class UppercaseRequest {

    private String input;

    public String getInput() {
        return input;
    }

    public void setInput(final String input) {
        this.input = input;
    }
}
