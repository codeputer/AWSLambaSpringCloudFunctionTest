package com.morethanheroic.uppercase.domain;

public class UppercaseResponse {

    private String result;

    public String getResult() {
        return result;
    }

    public void setResult(final String result) {
        this.result = result;
    }
}
